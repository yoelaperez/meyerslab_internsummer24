# Import Libraries
library(tidyverse)


# Import and modify 2018-2019 Flu Hospitalization Data

setwd("C:/Users/yoelp/Downloads")
getwd()

df <- read.table(
  file = "FluSurveillance_Custom_Download_Data.csv", 
  header = FALSE, 
  sep = ",", 
  fill = TRUE
)

df$V5 <- as.numeric(df$V5)
df$V9 <- as.numeric(df$V9)
df$V10 <- as.numeric(df$V10)

df$gen <- ifelse(
  df$V7 == "Overall" & df$V8 == "Overall",
  1,
  0
)


# Dataframes separated by year

season1 <- df %>% filter(V4 == "2018")
season2 <- df %>% filter(V4 == "2019")


####################################
# PUBLISHED GRAPH: FIGURE "ALPHA"

# A general plot of Weekly Hospitalization vs. Week

# Reduces large df to just the overall hospitalizations
# Across age, race, sex
Gen <- df %>% filter(gen == 1 & V6 == "Overall")

# Creates column from 1 to the final number of the total amount of season weeks
# Numerically in order start to finish
# Replace with string labels of CDC style Gregorian weeks
Gen$NumLabs <- c(seq(1, length(Gen$V5)))
Gen$WkLabs <- c(
  "40", "41", "42", "43", "44", "45", "46", "47",
  "48", "49", "50", "51", "52",  "1",  "2",  "3",  "4",
  "5",  "6",  "7",  "8", "9", "10", "11", "12", "13", "14", "15", "16", "17"
)

Gen %>%
  filter(!is.na(V10)) %>%
  ggplot(aes(NumLabs, V10)) +
  geom_point(size = 1.0) +
  labs(title="2018-2019 Flu Season: Weekly Hospitalization Rate") +
  xlab("Week (2018-2019)") +
  ylab("Hospitalization Rate (per 100,000 Population)") +
  scale_x_continuous(breaks = Gen$NumLabs, labels = Gen$WkLabs) +
  scale_y_continuous(breaks = seq(0, max(Gen$V10, na.rm = TRUE), by = 0.2)) +
  geom_line() +
  theme_bw()

####################################
# ALTERNATIVE GRAPHS

# Separated by sex

df %>%
  filter(V7 != "Overall", !is.na(V9)) %>% 
  ggplot(aes(V5, V9, colour = V7)) +
  geom_point(size = 2.0) +
  xlab("Weeks") +
  ylab("Cummulative Hospitalization Rate (per 100,000 Population)") +
  scale_y_continuous(breaks = seq(0, max(season2$V9, na.rm = TRUE), by = 2)) +
  guides(color = guide_legend(title = "Rate by Sex")) +
  facet_wrap(~V4) +
  theme_bw()


# Each year separately plotted

season1 %>%
  filter(V7 != "Overall", !is.na(V9)) %>% 
  ggplot(aes(V5, V9, colour = V7)) + 
  geom_point(size = 2.0) +
  xlab("2018 Weeks") +
  ylab("Cummulative Hospitalization Rate per 100,000 Population") +
  scale_x_continuous(breaks = seq(0, max(season1$V5, na.rm = TRUE), by = 1)) +
  scale_y_continuous(breaks = seq(0, max(season1$V9, na.rm = TRUE), by = 0.2)) +
  guides(color = guide_legend(title = "Rate by Sex")) +
  theme_bw()

season2 %>%
  filter(V7 != "Overall", !is.na(V9)) %>% 
  ggplot(aes(V5, V9, colour = V7)) + 
  geom_point(size = 2.0) +
  xlab("2019 Weeks") +
  ylab("Cummulative Hospitalization Rate per 100,000 Population") +
  scale_x_continuous(breaks = seq(0, max(season2$V5, na.rm = TRUE), by = 1)) +
  scale_y_continuous(breaks = seq(0, max(season2$V9, na.rm = TRUE), by = 2)) +
  guides(color = guide_legend(title = "Rate by Sex")) +
  theme_bw()


####################################
####################################



# Import and modify 2018-2019 Positive Test Specimen Data

setwd("C:/Users/yoelp/Downloads")
getwd()

df_2 <- read.table(
  file = "FluView_StackedColumnChart_Data.csv", 
  header = FALSE, 
  sep = ",", 
  fill = TRUE
)

# Renaming for easy in calling and coordinating color assignment
df_2$Year <- as.numeric(df_2$V1)
df_2$Wks <- as.numeric(df_2$V2)
df_2$Total <- as.numeric(df_2$V3)
df_2$H3 <- as.numeric(df_2$V4)
df_2$H1N1 <- as.numeric(df_2$V5)
df_2$NoTypeA <- as.numeric(df_2$V6)
df_2$B <- as.numeric(df_2$V7)
df_2$H3N2v <- as.numeric(df_2$V8)
df_2$BVic <- as.numeric(df_2$V9)
df_2$BYam <- as.numeric(df_2$V10)
df_2$H5A <- as.numeric(df_2$V11)

df_2 <- df_2[-1, ] # Removing non-numerical original label row


df_2$NumLabs <- c(seq(1, length(df_2$Wks)))
df_2$WkLabs <- c(
  "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51",
  "52", "1",  "2",  "3",  "4",  "5",  "6",  "7",  "8",  "9",  "10", "11", "12",
  "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25",
  "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38",
  "39"
)


####################################
# PUBLISHED GRAPH: FIGURE "BETA"

# Plot all specimen lines
df_2 %>% 
  ggplot() +
  geom_point(aes(NumLabs, Total), color = "blue", size = 1) +
  geom_line(aes(NumLabs, Total), color = "blue") +
  geom_point(aes(NumLabs, H1N1), color = "red", size = 1) +
  geom_line(aes(NumLabs, H1N1), color = "red") +
  geom_point(aes(NumLabs, H3), color = "green", size = 1) +
  geom_line(aes(NumLabs, H3), color = "green") +
  geom_point(aes(NumLabs, NoTypeA), color = "orange", size = 1) +
  geom_line(aes(NumLabs, NoTypeA), color = "orange") +
  geom_point(aes(NumLabs, B), color = "yellow", size = 1) +
  geom_line(aes(NumLabs, B), color = "yellow") +
  geom_point(aes(NumLabs, H3N2v), color = "pink", size = 1) +
  geom_line(aes(NumLabs, H3N2v), color = "pink") +
  geom_point(aes(NumLabs, BVic), color = "purple", size = 1) +
  geom_line(aes(NumLabs, BVic), color = "purple") +
  geom_point(aes(NumLabs, BYam), color = "blue4", size = 1) +
  geom_line(aes(NumLabs, BYam), color = "blue4") +
  geom_point(aes(NumLabs, H5A), color = "red4", size = 1) +
  geom_line(aes(NumLabs, H5A), color = "red4") +
  labs(title="2018-2019 Flu Season: Test-Positive Influenza Specimens Identified by Week") +
  xlab("Week (2018-2019)") +
  ylab("Number of Positive Specimens") +
  scale_y_continuous(breaks = seq(0, 5000, by = 200)) +
  scale_x_continuous(breaks = df_2$NumLabs, labels = df_2$WkLabs) +
  # LEGEND IS NOT APPEARING: scale_color_manual(values = c("Total" = "blue", "2009 H1N1" = "red")) +
  theme_bw()

####################################
# ALTERNATIVE GRAPHS

# Total Positive Specimen Found

df_2 %>%
  filter(!is.na(V2), !is.na(V3)) %>%
  ggplot(aes(V2, V3)) +
  geom_point(size = 1.0) +
  labs(title="2018-2019 Flu Season: Total Test-Positive Influenza Specimens by Week") +
  xlab("Week (2018-2019)") +
  ylab("Total Specimens") +
  scale_y_continuous(breaks = seq(0, max(df_2$V3, na.rm = TRUE), by = 200)) +
  geom_line() +
  facet_wrap(~V1) +
  theme_bw()


# Total 2009 H1N1 Found

df_2 %>%
  filter(!is.na(V2), !is.na(V5)) %>%
  ggplot(aes(V2, V5)) +
  geom_point(size = 1.0) +
  labs(title="2018-2019 Flu Season: Specimens (2009 H1N1) by Week") +
  xlab("Week") +
  ylab("H1N1 Specimens") +
  scale_y_continuous(breaks = seq(0, max(df_2$V5, na.rm = TRUE), by = 200)) +
  geom_line() +
  facet_wrap(~V1) +
  theme_bw()


####################################
####################################

# Import and modify 2018-2019 Percent of Visits for ILI Data

setwd("C:/Users/yoelp/Downloads")
getwd()

df_3 <- read.table(
  file = "FluView_LineChart_Data.csv", 
  header = FALSE, 
  sep = ",", 
  fill = TRUE
)

colnames(df_3) <- c("Year", "Week", "Age_0-4", "Age_5-24", "Age_25-49", "donotuse", "Age_50-64", "Age_65",
                   "ILI_Total", "Total_Patients", "Number_Providers", "per_Unweighted_ILI", "per_Weighted_ILI")

df_3 <- df_3[-1, ]
df_3 <- df_3[-1, ]

df_3$ILI_Total <- as.numeric(df_3$ILI_Total)
df_3$per_Unweighted_ILI <- as.numeric(df_3$per_Unweighted_ILI)
df_3$per_Weighted_ILI <- as.numeric(df_3$per_Weighted_ILI)

df_3$NumLabs <- c(seq(1, length(df_3$Week)))
df_3$WkLabs <- c(
  "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51",
  "52", "1",  "2",  "3",  "4",  "5",  "6",  "7",  "8",  "9",  "10", "11", "12",
  "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25",
  "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38",
  "39"
)

####################################
# PUBLISHED GRAPHS: FIGURES "GAMMA" AND "DEL"

# Total ILI Patient Visits
df_3 %>% 
  ggplot(aes(NumLabs, ILI_Total)) +
  geom_point() +
  geom_line() +
  labs(title="2018-2019 Flu Season: Total Patient Visits for Influenza-Like-Illness") +
  xlab("Week (2018-2019)") +
  ylab("Total ILI Visits (Individuals)") +
  scale_y_continuous(breaks = seq(0, 72000, by = 2000)) +
  scale_x_continuous(breaks = df_3$NumLabs, labels = df_3$WkLabs) +
  theme_bw()

# Weighted and Unweighted Percentages of Visits for ILI
df_3 %>% 
  ggplot() +
  geom_point(aes(NumLabs, per_Unweighted_ILI), color = "green4", size = 1) +
  geom_line(aes(NumLabs, per_Unweighted_ILI), color = "green4") +
  geom_point(aes(NumLabs, per_Weighted_ILI), color = "orange4", size = 1) +
  geom_line(aes(NumLabs, per_Weighted_ILI), color = "orange4") +
  labs(title="2018-2019 Flu Season: Unweighted and Weighted Percentages of Patient Visits for Influenza-Like-Illness") +
  xlab("Week (2018-2019)") +
  ylab("Percentage of Visits for ILI (%)") +
  scale_y_continuous(breaks = seq(0, 100, by = 1)) +
  scale_x_continuous(breaks = df_3$NumLabs, labels = df_3$WkLabs) +
  theme_bw()