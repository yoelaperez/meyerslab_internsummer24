###This is a demo code for synthetic data sent to Yoel by Oluwasegun Ibrahim

# Need to create age cohorts in syn data
samplesizeA <- 5000
samplesizeB <- 5000
totalss <- samplesizeA+samplesizeB

serial <- c(seq(1,(totalss)))
simdataset <- data.frame(serial)

simdataset$Group <- as.factor(c(rep("A", samplesizeA), rep("B", samplesizeB)))
str(simdataset)

## Gp B is the base case i.e. less effective
## Gp A more effective
simdataset$SymptomFreeDays <-  c(
  rnorm(n = samplesizeA, mean = 0.7398587*100, sd = 0.03579797*100),
  rnorm(n = samplesizeB, mean = 0.654222*100, sd = 0.03861657*100)
)
simdataset$ERvisits <- sample(c(0,1,1,1,2,2,2,3), size <- totalss, replace <- T)
simdataset$ER_visits_cost <- rnorm(n <- totalss, mean = 600, sd = 50)

## based on the following: <https://academic.oup.com/jid/article/221/3/356/5533434>
# see supplementary figure 1
simdataset$Hospitalization <- c(
  rnorm(n=samplesizeA, mean = 3.26, sd = 2) ,
  rnorm(n=samplesizeB, mean = 4, sd = 2)
  # Former code from O. Ibrahim:
  #sample(c(0,0,0,1,1,2), size = samplesizeA, replace = T),
  #sample(c(0,1,2,2), size = samplesizeB, replace = T)
)

simdataset$LOS_cost <- rnorm(n <-totalss, mean = 1600, sd = 150)
simdataset$MedicationUnits <- 
  sample(c(0,0,1,1,1), size <- samplesizeA, replace = T) # e.g. Baloxavir
  sample(c(5,6,7,8,9), size <- samplesizeB, replace = T) # e.g. Oseltamivir
simdataset$MedUnitCost <- c(
  rnorm(n=samplesizeA, mean = 481, sd = 0) ,
  rnorm(n=samplesizeB, mean = 170, sd = 0)
)

write.csv(simdataset, "simdataset.csv", row.names = F)
t.test(simdataset$SymptomFreeDays~simdataset$Group)


### Code by Yoel

## New columns 
# total cost per patient
simdataset$TotalCost <- simdataset$ER_visits_cost + simdataset$LOS_cost + simdataset$MedUnitCost

# Using Excel "Payoffs" Sheet, Utility of "No drug", a intermediate quantity,
# and "Hospitalizations"
simdataset$TotalUtility <- 
  (simdataset$SymptomFreeDays * rnorm(n=totalss, mean=0.88, sd=0.1)) +
  (simdataset$ERvisits * rnorm(n=totalss, mean=0.44, sd=0.1)) +
  (simdataset$Hospitalization * rnorm(n=totalss, mean=0.25, sd=0.1))


  
## Visualization

library(tidyverse)

# TotalCost v. TotalUtility
simdataset %>%
  filter(TotalCost>1930, TotalCost<3040) %>%
  ggplot(aes(TotalUtility,TotalCost, shape= Group, colour = Group)) + 
  geom_point(alpha=0.7, size = 0.5) +
  labs(title = "Cost vs. Utility", x = "Utility", y = "Cost") +
  theme_bw()

# TotalCost v. SymptomFreeDays
simdataset %>%
  filter(TotalCost>1930, TotalCost<3040) %>%
  ggplot(aes(SymptomFreeDays,TotalCost, colour = Group)) + 
  geom_point(alpha=0.7, size = 0.5)

# TotalCost v. ERvisits, smooth line through rough mean
simdataset %>%
  ggplot(aes(ERvisits, TotalCost, colour = Group)) +
  geom_point() +
  geom_smooth() +
  facet_wrap(~Group)


## ICERs

GroupA <- simdataset %>% filter(Group == "A")
GroupB <- simdataset %>% filter(Group == "B")
deltatab <- data.frame((GroupA$TotalCost - GroupB$TotalCost),
                  (GroupA$TotalUtility - GroupB$TotalUtility))
names(deltatab) <- c("deltaCost", "deltaUtil")

deltatab %>%
  ggplot(aes(deltaUtil,deltaCost)) + 
  geom_point(colour = "blue", shape = "triangle", size = 0.5) +
  labs(title = "Cost vs. Utility", x = "Utility", y = "Cost") +
  theme_bw()

# CEA Plot

plot(deltatab$deltaCost~deltatab$deltaUtil, xlab="Effect", ylab="Cost",
     col="red", cex=.6, pch=2, xlim=c(-60, 60),ylim=c(-1500,1500))
abline(h=0, lwd=2)
abline(v=0, lwd=2)

WTP = 100

abline(c(0, WTP), col="blue", lwd=2)

deltatab$model <- WTP - deltatab$deltaUtil
deltatab$model_true <- deltatab$model - deltatab$deltaCost
deltatab$CE <- ifelse(test = deltatab$model_true>0, yes=1, no=0)
table(deltatab$CE)