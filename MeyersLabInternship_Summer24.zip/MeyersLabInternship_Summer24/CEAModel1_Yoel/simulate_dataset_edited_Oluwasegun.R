###This is a demo code for synthetic data sent to Yoel by Oluwasegun Ibrahim

samplesizeA = 150
samplesizeB = 150
totalss = samplesizeA+samplesizeB

serial = c(seq(1,(totalss)))
simdataset = as.data.frame(serial)
simdataset$Group = as.factor(c(rep("A", samplesizeA), rep("B", samplesizeB)))
str(simdataset)
## case B is the base case i.e. less effective
simdataset$SymptomFreeDays = c(
  rnorm(n=samplesizeA, mean = 0.7398587*100, sd = 0.03579797*100), ## Gp A more eefective
  rnorm(n=samplesizeB, mean = 0.654222*100, sd = 0.03861657*100)
)
simdataset$ERvisits = sample(c(0,1,1,1,2,2,2,3), size = totalss, replace = T)
simdataset$ER_visits_cost = rnorm(n=totalss, mean = 600, sd = 50)
simdataset$Hospitalization = c(
  sample(c(0,0,0,1,1,2), size = samplesizeA, replace = T),
  sample(c(0,1,2,2), size = samplesizeB, replace = T)
)
simdataset$LOS_cost = rnorm(n=totalss, mean = 1600, sd = 150)
simdataset$MedicationUnits = sample(c(5,6,7,8,9), size = totalss, replace = T)
simdataset$MedUnitCost = c(
  rnorm(n=samplesizeA, mean = 481, sd = 0) ,
  rnorm(n=samplesizeB, mean = 170, sd = 0)
)

write.csv(simdataset, "simdataset.csv", row.names = F)
t.test(simdataset$SymptomFreeDays~simdataset$Group)
