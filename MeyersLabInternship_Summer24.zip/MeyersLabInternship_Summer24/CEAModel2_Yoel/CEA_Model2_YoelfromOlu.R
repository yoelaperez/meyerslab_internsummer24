# Note, code is inspired from video <https://www.youtube.com/watch?v=Z_Q_3de9zJ4>
# Editing and optimization was aided by ChatGPT

### This is Yoel's adaptation of code for Week of 07/29/24
library(tidyverse)


# Population sizes by Treatment, A is more effective (Baloxavir)
samplesizeA <- 5000
samplesizeB <- 5000
totalss <- samplesizeA + samplesizeB

# Patient ID's in order
serial <- c(seq(1,(totalss)))
simdataset <- data.frame(serial)

# Column = "Group"
simdataset$Group <- as.factor(c(rep("A", samplesizeA), rep("B", samplesizeB)))

# Column = "Hospitalized", Probabilities based on Paper: <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8423480/>
# Using Beta distribution to generate probabilities
# Then use these probabilities to determine hospitalization status
prob_hosp_A <- rbeta(samplesizeA, shape1 = 2, shape2 = 14)  # Mean approx 0.13
prob_hosp_B <- rbeta(samplesizeB, shape1 = 6, shape2 = 19)  # Mean approx 0.24

simdataset$Hospitalized <- c(
  rbinom(samplesizeA, size = 1, prob = prob_hosp_A),
  rbinom(samplesizeB, size = 1, prob = prob_hosp_B)
)

# LOS will only set in if the patient was hospitalized in the first place
# Based roughly on <https://publications.aap.org/pediatrics/article/148/4/e2021050417/181290/Influenza-Antiviral-Treatment-and-Length-of-Stay?autologincheck=redirected>
# E.g. prev attempted bootstrapping data with "sample(c(1,1,1,2,2,2,3,3,4,5,6,7)" and "size = samplesizeA"
# Length of Stay (LOS) using Gamma distribution, only for hospitalized patients
simdataset$LOS <- ifelse(
  simdataset$Hospitalized == 1, 
  rgamma(sum(simdataset$Hospitalized), shape = 6.8, scale = 0.75),  # Based on appendix from <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2957998/>
  0
)

# Based on paper: <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9897209/>
simdataset$LOS_cost <- ifelse(
  (simdataset$Hospitalized == 1), 
  rnorm(n <-totalss, mean = 16800, sd = 5000),
  0
)

# Based on Excel Payoffs sheet
simdataset$MedUnitCost <- c(
  rnorm(n=samplesizeA, mean = 170.49, sd = 0) ,
  rnorm(n=samplesizeB, mean = 50.00, sd = 0)
)

# total cost per patient
simdataset$TotalCost <- (simdataset$LOS * simdataset$LOS_cost) + simdataset$MedUnitCost

# Using Excel "Payoffs" Sheet, Utility of "No drug", a intermediate quantity,
# and "Hospitalizations"
simdataset$TotalUtility <- ifelse(
  (simdataset$Hospitalized == 1), 
  (simdataset$LOS * 0.25), 
  5*0.88 
  # Max utility was 0.88 in Padula paper, 
  # multiplied by the max days possible to be hospitalized
  # during which patients where LOS is 0 were not hospitalized
)


## ICERs

GroupA <- simdataset %>% filter(Group == "A")
GroupB <- simdataset %>% filter(Group == "B")
deltatab <- data.frame((GroupA$TotalCost - GroupB$TotalCost),
                       (GroupA$TotalUtility - GroupB$TotalUtility))
names(deltatab) <- c("deltaCost", "deltaUtil")

# CE Plane

plot(deltatab$deltaCost~deltatab$deltaUtil, 
     main = "Cost-Effectiveness Plane", xlab="Incremental Effect (QALYs)", ylab="Cost ($)",
     col="red", cex=.6, pch=1) #xlim=c(-1, 1), #ylim=c(-150000,150000)
abline(h=0, lwd=2)
abline(v=0, lwd=2)

# The willingness to pay will be varied from 10,000 to 70,000
# Based on paper: <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2957998/>
WTP <- c(10000, 20000, 30000, 40000, 50000, 60000, 70000)
percentCE <- numeric(length(WTP))  # To store the ratios of pts CE

for (i in seq_along(WTP)) {
  abline(a = 0, b = WTP[i], col = "blue", lwd = 2)
  
  deltatab$model <- WTP[i] - deltatab$deltaUtil
  deltatab$model_true <- deltatab$model - deltatab$deltaCost
  deltatab$CE <- ifelse(deltatab$model_true > 0, 1, 0)
  
  # Calculate and store the ratio of cost-effective points
  percentCE[i] <- sum(deltatab$CE) / samplesizeA
  
  # Print the ratio for the current WTP value
  cat("WTP:", WTP[i], "; Percent of cost-effective points:", percentCE[i], "\n")
}

# Plotting CEAC
plot(WTP, percentCE, 
     type="b", ylim=c(0,1.00), col="blue", 
     main = "Cost-Effectiveness Acceptability Curve", xlab="WTP Threshold ($/QALY)", ylab="Pr(C-E)")


# Calculate mean LOS and TotalCost for each group
mean_values <- simdataset %>%
  group_by(Group) %>%
  summarise(mean_LOS = mean(LOS), mean_TotalCost = mean(TotalCost))


# Difference in Costs Comparing Length of Stay
simdataset %>%
  # filter(TotalCost>0, TotalCost<40000) %>%
  ggplot(aes(LOS,TotalCost, shape= Group, colour = Group)) + 
  geom_point(alpha = 0.7, size = 1.0) +
  theme_bw() +
  facet_wrap(~Group) +
  geom_point(data = mean_values, aes(x = mean_LOS, y = mean_TotalCost), 
             colour = "black", shape = 8, stroke = 2, alpha = 0.7, size = 2) +  # Add mean points
  labs(title = "Total Cost vs. Length of Stay by Treatment",
       x = "Length of Stay (LOS)", y = "Total Cost")
print(mean_values)
