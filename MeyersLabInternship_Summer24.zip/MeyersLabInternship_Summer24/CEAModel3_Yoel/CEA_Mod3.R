### This is Yoel's adaptation of code for Week of 08/05/24
library(tidyverse)

## Based off paper <https://www.ajmc.com/view/baloxavir-vs-oseltamivir-reduced-utilization-and-costs-in-influenza>
## Using 15-day outcomes

# Population sizes by Treatment, A is more effective (Baloxavir) vs. B (Oseltamivir)
samplesizeA <- 5000
samplesizeB <- 10000
totalss <- samplesizeA + samplesizeB

# Patient ID's in order
id <- c(seq(1, (totalss)))
simdataset <- data.frame(id)

# Treatment group as categories
simdataset$group <- as.factor(c(rep("A", samplesizeA), rep("B", samplesizeB)))

# Initial treatment cost
simdataset$trtcourse_cost <- c(
  rnorm(n=samplesizeA, mean = 170.49, sd = 0) ,
  rnorm(n=samplesizeB, mean = 50.00, sd = 0)
)

# HCRU measured in events
# Costs measured in 2019 USD
# Based on 15-day outcomes following Treatment

# ER visits
simdataset$er_event <- c(
  rnorm(n=samplesizeA, mean = 0.034, sd = 0.21819),
  rnorm(n=samplesizeB, mean = 0.085, sd = 0.30856)
)
simdataset$er_cost <- c(
  rnorm(n=samplesizeA, mean = 58, sd = 472.737),
  rnorm(n=samplesizeB, mean = 154, sd = 822.831)
)

# Hospitalization
simdataset$hosp_event <- c(
  rnorm(n=samplesizeA, mean = 0.002, sd = 0.03636),
  rnorm(n=samplesizeB, mean = 0.004, sd = 0.10285)
)
simdataset$hosp_cost <- c(
  rnorm(n=samplesizeA, mean = 31, sd = 872.744),
  rnorm(n=samplesizeB, mean = 82, sd = 1645.66)
)

# Outpatient visits
simdataset$outpt_event <- c(
  rnorm(n=samplesizeA, mean = 1.4, sd = 0.72729),
  rnorm(n=samplesizeB, mean = 1.39, sd = 0.51427)
)
simdataset$outpt_cost <- c(
  rnorm(n=samplesizeA, mean = 271, sd = 727.287),
  rnorm(n=samplesizeB, mean = 281, sd = 977.112)
)

# Prescription pick-ups
simdataset$pres_event <- c(
  rnorm(n=samplesizeA, mean = 2.39, sd = 1.81822),
  rnorm(n=samplesizeB, mean = 2.4, sd = 1.54281)
)
simdataset$pres_cost <- c(
  rnorm(n=samplesizeA, mean = 252, sd = 1090.93),
  rnorm(n=samplesizeB, mean = 179, sd = 771.404)
)

# Summary of healthcare utiilization events
simdataset$total_events <- 
  simdataset$er_event +
  simdataset$hosp_event +
  simdataset$outpt_event +
  simdataset$pres_event

# total cost per patient
simdataset$totalcost <- 
  simdataset$trtcourse_cost + 
  simdataset$er_cost + 
  simdataset$hosp_cost + 
  simdataset$outpt_cost + 
  simdataset$pres_cost

# Utilities based off WV Padula, et. al.
# KEY: er_event = i2, hosp_event =  i3, outpt_event = i, pres_event = e
simdataset$totalutility <- 
  (simdataset$er_event * 0.500) +
  (simdataset$hosp_event * 0.250) +
  (simdataset$outpt_event * 0.833) +
  (simdataset$pres_event * 0.880)


# ICERs
GroupA <- simdataset %>% filter(group == "A")
GroupB <- simdataset %>% filter(group == "B")
deltatab <- data.frame((GroupA$totalcost - GroupB$totalcost),
                       (GroupA$totalutility - GroupB$totalutility))
names(deltatab) <- c("deltaCost", "deltaUtil")


## VISUALIZATION

# CE Plane
plot(deltatab$deltaCost~deltatab$deltaUtil, 
     main = "Cost-Effectiveness Plane", xlab="Incremental Effect (QALYs)", ylab="Incremental Cost ($)",
     col="red", cex=.6, pch=1)
abline(h=0, lwd=2)
abline(v=0, lwd=2)

# The willingness to pay will be varied from 1,000 to 10,000
# Based on plot window
WTP <- c(1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000)
percentCE <- numeric(length(WTP))  # To store the ratios of pts CE

for (i in seq_along(WTP)) {
  abline(a = 0, b = WTP[i], col = "blue", lwd = 2)
  
  deltatab$model <- WTP[i] - deltatab$deltaUtil
  deltatab$model_true <- ifelse(deltatab$deltaCost>0,
    deltatab$model - deltatab$deltaCost, 0) # Cost effective only counts if points are + deltaCost
  deltatab$CE <- ifelse(deltatab$model_true > 0, 1, 0)
  
  # Calculate and store the ratio of cost-effective points
  percentCE[i] <- sum(deltatab$CE) / samplesizeA
  
  # Print the ratio for the current WTP value
  cat("WTP:", WTP[i], "; Percent of cost-effective points:", percentCE[i], "\n")
}


# Plotting CEAC
plot(WTP, percentCE, 
     type="b", ylim=c(0,1.00), col="blue", 
     main = "Cost-Effectiveness Acceptability Curve", xlab="WTP Threshold ($/QALY)", ylab="Pr(C-E)")
# All appear over 100% cost-effective


# Calculate mean LOS and TotalCost for each group
mean_values <- simdataset %>%
  group_by(group) %>%
  summarise(mean_HCRU = mean(total_events), mean_TotalCost = mean(totalcost))


# Difference in Costs Comparing HCRU
simdataset %>%
  # filter(TotalCost>0, TotalCost<40000) %>%
  ggplot(aes(total_events,totalcost, shape= group, colour = group)) + 
  geom_point(alpha = 0.7, size = 1.0) +
  theme_bw() +
  facet_wrap(~group) +
  geom_point(data = mean_values, aes(x = mean_HCRU, y = mean_TotalCost), 
             colour = "black", shape = 8, stroke = 2, alpha = 0.7, size = 2) +  # Add mean points
  labs(title = "Total Cost vs. HCRU Events by Treatment",
       x = "Healthcare Resource Utilizations (HCRU) Events", y = "Total Cost")
print(mean_values)