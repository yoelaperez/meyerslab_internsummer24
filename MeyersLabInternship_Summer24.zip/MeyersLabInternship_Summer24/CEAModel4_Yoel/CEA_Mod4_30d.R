# Import multiple libraries for expanded functionality
library(tidyverse)
options(scipen = 999) # Turn off scientific notation

## Mostly based off paper <https://www.ajmc.com/view/baloxavir-vs-oseltamivir-reduced-utilization-and-costs-in-influenza>
## Using 30-day outcomes

# Population sizes by Treatment, A is more effective (Baloxavir) vs. B (Oseltamivir)
samplesizeA <- 5000
samplesizeB <- 10000
samplesizeC <- 10000 # Control (No-Treatment), Propensity Matched with B, 1:1, originally N=31k
totalss <- samplesizeA + samplesizeB + samplesizeC

# Patient ID's in order
id <- c(seq(1, (totalss)))
simdataset <- data.frame(id)

# Treatment group as categories
simdataset$group <- as.factor(c(rep("A", samplesizeA), rep("B", samplesizeB), rep("C", samplesizeC)))

# Initial treatment cost
simdataset$trtcourse_cost <- c(
  rnorm(n=samplesizeA, mean = 170.49, sd = 0),
  rnorm(n=samplesizeB, mean = 50.00, sd = 0),
  rnorm(n=samplesizeB, mean = 0.00, sd = 0) # No drug is taken in control
)

# HCRU measured in events
# A and B costs measured in 2019 USD
# Based on 30-day outcomes following Treatment

# C costs are CPI appx. for 2019 from 2005 USD, Peters et. al.
# C outcomes are from Wayan et. al.

# ER visits
simdataset$er_event <- c(
  rnorm(n=samplesizeA, mean = 0.044, sd = 0.21819),
  rnorm(n=samplesizeB, mean = 0.097, sd = 0.17999),
  rnorm(n=samplesizeC, mean = 650865/26213478, sd = 0) # Standard deviation = 0 in order to make the HCRU standard across control
)
simdataset$er_cost <- c(
  rnorm(n=samplesizeA, mean = 74, sd = 545.465),
  rnorm(n=samplesizeB, mean = 179, sd = 462.842),
  rnorm(n=samplesizeC, mean = 56*1.672, sd = 228*1.672)
)

# Hospitalization
simdataset$hosp_event <- c(
  rnorm(n=samplesizeA, mean = 0.003, sd = 0.07273),
  rnorm(n=samplesizeB, mean = 0.007, sd = 0.02571),
  rnorm(n=samplesizeC, mean = 247004/26213478, sd = 0)
)
simdataset$hosp_cost <- c(
  rnorm(n=samplesizeA, mean = 47, sd = 1200.023),
  rnorm(n=samplesizeB, mean = 128, sd = 1079.966),
  rnorm(n=samplesizeC, mean = 111*1.672, sd = 1525*1.672)
)

# Outpatient visits
simdataset$outpt_event <- c(
  rnorm(n=samplesizeA, mean = 1.83, sd = 1.45457),
  rnorm(n=samplesizeB, mean = 1.79, sd = 0.77140),
  rnorm(n=samplesizeC, mean = 3728150/26213478, sd = 0)
)
simdataset$outpt_cost <- c(
  rnorm(n=samplesizeA, mean = 411, sd = 1309.116),
  rnorm(n=samplesizeB, mean = 410, sd = 668.5504),
  rnorm(n=samplesizeC, mean = 346*1.672, sd = 1176*1.672)
)

# Prescription pick-ups
simdataset$pres_event <- c(
  rnorm(n=samplesizeA, mean = 2.97, sd = 2.18186),
  rnorm(n=samplesizeB, mean = 2.92, sd = 1.02854),
  rnorm(n=samplesizeC, mean = 21551129/26213478, sd = 0)
)
simdataset$pres_cost <- c(
  rnorm(n=samplesizeA, mean = 345, sd = 1963.6747),
  rnorm(n=samplesizeB, mean = 251, sd = 514.2695),
  rnorm(n=samplesizeC, mean = 96*1.672, sd = 225*1.672)
)

# Summary of healthcare utilization events
simdataset$total_events <- 
  simdataset$er_event +
  simdataset$hosp_event +
  simdataset$outpt_event +
  simdataset$pres_event

# total cost per patient
simdataset$totalcost <- 
  simdataset$trtcourse_cost + 
  simdataset$er_cost + 
  simdataset$hosp_cost + 
  simdataset$outpt_cost + 
  simdataset$pres_cost

# Utilities based off WV Padula, et. al.
# KEY: er_event = i2, hosp_event =  i3, outpt_event = i, pres_event = e

# Multiplied by the median number of days out of the year patients were sick with Flu
# According to Hollmann et. al. and thus also being the total amount of time patients could receive utility from each outcome

simdataset$totalutility <- 
  (simdataset$er_event * 0.500) * (7 / 365) + # Utility gained for the days with illness
  (simdataset$hosp_event * 0.250) * (21 / 365) + # Inpatients tended to be sick for longer
  (simdataset$outpt_event * 0.833) * (7 / 365) +
  (simdataset$pres_event * 0.880) * (7 / 365)


# ICER Inputs (separated by cost and effect, no stored as computed ratios)
GroupA <- simdataset %>% filter(group == "A")
GroupB <- simdataset %>% filter(group == "B")
GroupC <- simdataset %>% filter(group == "C")
deltatab <- data.frame(
  (GroupA$totalcost - GroupC$totalcost),
  (GroupA$totalutility - GroupC$totalutility),
  (GroupB$totalcost - GroupC$totalcost),
  (GroupB$totalutility - GroupC$totalutility),
  (GroupA$totalcost - GroupB$totalcost), # May be useful if want to use Oseltamivir as the baseline
  (GroupA$totalutility - GroupB$totalutility)
)
names(deltatab) <- c("deltaCost_A", "deltaUtil_A", 
                     "deltaCost_B", "deltaUtil_B",
                     "deltaCost_trt", "deltaUtil_trt")



####################################

## VISUALIZATION

# CE Plane
plot(deltatab$deltaCost_A~deltatab$deltaUtil_A, 
     main = "Cost-Effectiveness Plane (30-Day Outcomes)", xlab="Incremental Effect (QALYs)", ylab="Incremental Cost ($)",
     col="red", cex=.6, pch=1)
points(deltatab$deltaCost_B~deltatab$deltaUtil_B, col="blue", cex=.6, pch=1)
abline(h=0, lwd=2)
abline(v=0, lwd=2)
legend("topright", legend=c("Baloxavir", "Oseltamivir"), col=c("red", "blue"), pch=c(1, 2))

# The willingness to pay will be varied relative to plot window and data distribution
# Values and coloring may be modified as needed
WTP <- c(10000, 50000, 100000, 400000, 700000)
percentCE_A <- numeric(length(WTP))
percentCE_B <- numeric(length(WTP)) # To store the ratios of pts CE
WTP_col <- c("darkseagreen1", "darkseagreen2", "darkolivegreen1","darkolivegreen2", "darkseagreen4")

# The following loop plots each willingness to pay value as the slope of a line beginning a (0,0),
# and then computes what percentage of points in each distribution are less than or equal to
# that WTP, or cost-effective (since the units of $/QALY are the same for points and WTP)
for (i in seq_along(WTP)) {
  abline(a = 0, b = WTP[i], col = WTP_col[i], lwd = 2)
  
  ## Plotting the cost-effect distribution for A versus Control
  deltatab$model_A <- WTP[i]
  deltatab$model_true_A <- deltatab$model_A - (deltatab$deltaCost_A / deltatab$deltaUtil_A)
    # Earlier alternative: Cost effective only counts if points are + deltaCost
    # deltatab$model_true <- ifelse(deltatab$deltaCost_A>0, deltatab$model - deltatab$deltaCost_A, 0) 
  deltatab$CE_A <- ifelse(deltatab$model_true_A > 0, 1, 0)
    # Calculate and store the ratio of cost-effective points
  percentCE_A[i] <- sum(deltatab$CE_A) / samplesizeC
    # Print the ratio for the current WTP value
  cat("WTP:", WTP[i], "; Percent of cost-effective points (A):", percentCE_A[i], "\n")
  
  ## Plotting the cost-effect distribution for B versus Control
  deltatab$model_B <- WTP[i]
  deltatab$model_true_B <- deltatab$model_B - (deltatab$deltaCost_B / deltatab$deltaUtil_B)
    # Earlier alternative: Cost effective only counts if points are + deltaCost
    # deltatab$model_true <- ifelse(deltatab$deltaCost_B>0, deltatab$model - deltatab$deltaCost_B, 0) 
  deltatab$CE_B <- ifelse(deltatab$model_true_B > 0, 1, 0)
    # Calculate and store the ratio of cost-effective points
  percentCE_B[i] <- sum(deltatab$CE_B) / samplesizeC
    # Print the ratio for the current WTP value
  cat("WTP:", WTP[i], "; Percent of cost-effective points (B):", percentCE_B[i], "\n")
}



####################################

# Plotting CEAC
plot(WTP, percentCE_A, type="b", col="red", ylim=c(0.4, 1.0), cex = 1.5,
     main = "Cost-Effectiveness Acceptability Curve (30-Day Outcomes)", 
     xlab="WTP Threshold ($/QALY)", ylab="Probability of (C-E)")

lines(WTP, percentCE_B, type="b", col="blue", pch = 2)
legend("bottomright", legend=c("Baloxavir", "Oseltamivir"), col=c("red", "blue"), pch=c(1, 2))



# More aesthetic CEAC

ggplot() +
  geom_point(aes(WTP, percentCE_A), color = "blue", size = 3) +
  geom_line(aes(WTP, percentCE_A), color = "blue", linetype = 2) +
  geom_point(aes(WTP, percentCE_B), color = "red", size = 3) +
  geom_line(aes(WTP, percentCE_B), color = "red", linetype = "dotdash") +
  labs(title="Cost-Effectiveness Acceptability Curve") +
  xlab("Willingness to Pay") +
  ylab("Probability of Being Cost-Effective") +
  theme_bw()


####################################


# Calculate mean HCRU Events (considering total per patient) 
# and Total Cost for each group
simdataset$Group <- simdataset$group # For legend labeling

mean_values <- simdataset %>%
  group_by(Group) %>%
  summarise(mean_HCRU = mean(total_events), mean_TotalCost = mean(totalcost))


# Difference in Costs Comparing HCRU
simdataset %>%
  ggplot(aes(total_events,totalcost, shape = Group, colour = Group)) + 
  geom_point(alpha = 0.7, size = 1.0) +
  theme_bw() +
  facet_wrap(~Group) +
  geom_point(data = mean_values, aes(x = mean_HCRU, y = mean_TotalCost), 
             colour = "black", shape = 8, stroke = 2, alpha = 0.7, size = 2) +  # Add mean points
  labs(title = "Total Cost vs. Healthcare Resource Utilization (30-Day Outcomes) by Treatment Group",
       x = "Healthcare Resource Utilization (HCRU) Events", y = "Total Cost (2019 USD)")
print(mean_values)


####################################

# LEAVE FOR FURTHER TESTING

# OLD WILLINGNESS TO PAY DATA
# WTP <- c(1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000)
# WTP_col <- c(
#   "darkseagreen1", "darkseagreen2", "darkseagreen3", "darkolivegreen1","darkolivegreen2",
#   "darkolivegreen3", "darkseagreen","darkseagreen4","darkolivegreen4","darkolivegreen"
# )